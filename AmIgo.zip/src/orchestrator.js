// Оркестратор: модель — ядро вывода, этот слой собирает ход.
// Структура как у облачных API: (1) identity, (2) короткие правила качества,
// (3) карточка задачи в хвосте user-сообщения. UI не меняется.

import { isConciseCapabilityQuestion, isUnlimitedCreationTask, wantsDocumentExport } from './chatLogic.js';

export function isImageFilename(name) {
  return /\.(png|jpe?g|gif|bmp|webp|heic|heif|tiff?|avif)$/i.test(String(name || ''));
}

export function isAudioFilename(name) {
  return /\.(mp3|m4a|wav|aac|flac|ogg|opus|aiff|caf)$/i.test(String(name || ''));
}

export function collectAttachmentDocuments(messages) {
  const docs = [];
  const seen = new Set();
  for (const message of messages || []) {
    for (const attachment of message.attachments || []) {
      if (!attachment || attachment.kind === 'image' || attachment.kind === 'audio') continue;
      const text = String(attachment.text || '').trim();
      if (!text) continue;
      const name = attachment.sandboxPath || attachment.name || 'document';
      if (seen.has(name)) continue;
      seen.add(name);
      docs.push({ name, text });
    }
  }
  return docs;
}

export function classifyTurn({
  text = '',
  attachments = [],
  sandboxFiles = [],
  searchAvailable = false,
  continueMsg = false,
  previousUser = '',
} = {}) {
  const source = String(text || '');
  const lower = source.toLocaleLowerCase('ru');
  const hasImages = (attachments || []).some((item) => item?.kind === 'image');
  const searchAfterVision = hasImages && (
    /похож/i.test(lower)
    || /similar/i.test(lower)
    || /(?:найди|поищи|покажи).{0,50}(?:как на|как эт|такие)/i.test(lower)
  );
  const hasAudio = (attachments || []).some((item) => item?.kind === 'audio');
  const hasTextAttachments = (attachments || []).some((item) => item && item.kind !== 'image' && item.kind !== 'audio');
  const hasSandboxText = (sandboxFiles || []).some((name) => name && !isImageFilename(name) && !isAudioFilename(name));
  const hasTextFiles = hasTextAttachments || hasSandboxText;

  if (continueMsg) return { intent: 'continue', hasImages, hasAudio, hasTextFiles, searchAfterVision };
  if (isConciseCapabilityQuestion(source, previousUser)) return { intent: 'capability', hasImages, hasAudio, hasTextFiles, searchAfterVision };

  if (wantsDocumentExport(source)) {
    return { intent: 'create', hasImages, hasAudio, hasTextFiles };
  }

  const analyzeFile = (hasTextAttachments || hasSandboxText) && /(?:прочитай|проанализируй|разбери|суммариз|перескажи|изучи|что в(?:нутри)?|по этому файлу|по документу|найди в|выпиши|цитат|о чём|о чем|содерж)/i.test(lower);
  if (analyzeFile) return { intent: 'file_qa', hasImages, hasAudio, hasTextFiles };
  if (hasTextAttachments && source.trim().length < 80 && !/(?:создай|напиши|сделай|исправь|перепиши|переделай|оформи)/i.test(lower)) {
    return { intent: hasImages ? 'vision_files' : 'file_qa', hasImages, hasAudio, hasTextFiles };
  }

  if (isUnlimitedCreationTask(source, attachments)) {
    const codey = /(?:код|скрипт|программ|html|css|javascript|typescript|python|rust|компонент|функци|класс|\.py|\.js|\.ts|\.tsx|\.html)/i.test(lower);
    return { intent: codey ? 'code' : 'create', hasImages, hasAudio, hasTextFiles };
  }

  const mentionedFile = (sandboxFiles || []).some((name) => {
    const base = String(name || '').split(/[\\/]/).pop() || '';
    return base && lower.includes(base.toLocaleLowerCase('ru'));
  });
  if (hasSandboxText && mentionedFile && !/(?:создай|напиши|сделай|исправь|перепиши|переделай|оформи)/i.test(lower)) {
    return { intent: hasImages ? 'vision_files' : 'file_qa', hasImages, hasAudio, hasTextFiles };
  }

  if (hasAudio && !hasTextFiles && !hasImages) {
    return { intent: 'audio', hasImages, hasAudio, hasTextFiles };
  }
  if (hasImages) return { intent: hasTextFiles ? 'vision_files' : 'vision', hasImages, hasAudio, hasTextFiles, searchAfterVision };
  if (hasAudio) return { intent: 'audio', hasImages, hasAudio, hasTextFiles };

  if (searchAvailable && /(?:найди|поищи|поиск|в интернете|новост|погода|курс валют|сколько стоит|картин|изображ|(?:покажи|скинь|пришли|скачай)[^\n]{0,40}фото)/i.test(lower)) {
    return { intent: 'search', hasImages, hasAudio, hasTextFiles };
  }
  const trimmed = source.trim();
  if (
    trimmed.length >= 16
    && trimmed.length <= 400
    && /^(?:а\s+|ну\s+)?(?:объясни|объясните|как работает|как устроен[оа]?|почему|зачем|что такое|что значит|в чём разница|в чем разница|расскажи(?:те)? (?:подробно )?(?:про|о)\s)/i.test(trimmed)
  ) {
    return { intent: 'explain', hasImages, hasAudio, hasTextFiles };
  }
  return { intent: 'chat', hasImages, hasAudio, hasTextFiles };
}

export function shouldGatherEvidence({ intent, continueMsg, attachments, sandboxFiles }) {
  if (continueMsg) return false;
  const hasTextAtt = (attachments || []).some((item) => item && item.kind !== 'image' && item.kind !== 'audio');
  const hasSandboxText = (sandboxFiles || []).some((name) => name && !isImageFilename(name) && !isAudioFilename(name));
  if (!hasTextAtt && !hasSandboxText) return false;
  if (hasTextAtt) return true;
  return ['file_qa', 'vision_files', 'code', 'create'].includes(intent);
}

export function compactDroppedMessages(messages, { maxItems = 10, maxChars = 1600 } = {}) {
  const list = Array.isArray(messages) ? messages : [];
  if (!list.length) return '';
  const lines = [];
  for (const message of list.slice(-maxItems * 2)) {
    const role = message.role === 'user' ? 'Пользователь' : 'Ассистент';
    let content = String(message.content || '').replace(/\s+/g, ' ').trim();
    if (!content) {
      const names = (message.attachments || []).map((item) => item.name).filter(Boolean);
      if (names.length) content = `[вложения: ${names.join(', ')}]`;
      else continue;
    }
    if (content.length > 200) content = `${content.slice(0, 200)}…`;
    lines.push(`${role}: ${content}`);
  }
  let text = lines.join('\n');
  if (text.length > maxChars) text = text.slice(-maxChars);
  return text ? `[Сжатая ранняя история]\n${text}` : '';
}

// Сравнение в чате: модель должна отвечать таблицей, а не столбиком абзацев.
export function wantsComparisonTable(text) {
  const source = String(text || '');
  if (!source.trim()) return false;
  return /сравни(?:ть|те|м)(?!\p{L})|сравни\s|сравнени[еяю]|сопостав|в чём разниц|в чем разниц|чем отлича|какая разниц|какие отличи|\bversus\b|\bvs\.?\b|что лучше[\s\S]{0,40}\bили\b|какой лучше[\s\S]{0,40}\bили\b|с аналог/iu.test(source);
}

// Короткая карточка в КОНЦЕ user-сообщения: 4B/9B сильнее слушают хвост, не system.
export function buildTaskCard({
  intent = 'chat',
  isCoder = false,
  evidencePresent = false,
  nowLabel = '',
  searchAfterVision = false,
  wantsTable = false,
} = {}) {
  if (isCoder || intent === 'continue' || intent === 'capability' || intent === 'audio') return '';
  let card = '';
  if (intent === 'file_qa' || intent === 'vision_files') {
    card = evidencePresent
      ? '[Задача] ответить по фрагментам ниже'
      : '[Задача] ответить по файлам';
    if (searchAfterVision) card += '\n[Сделай] сначала по фото, затем find_images по тому, что видно';
  } else if (intent === 'code' || intent === 'create') {
    card = '[Задача] сделать один файл\n[Сделай] create_document; в content markdown-таблица с |; не пиши «файл создан»';
  } else if (intent === 'search') {
    card = '[Задача] ответить по найденным источникам\n[Сделай] сначала факт, потом коротко откуда\n[Нельзя] выдумывать ссылки; не искать картинки повторно, если галерея уже есть';
  } else if (intent === 'vision') {
    card = searchAfterVision
      ? '[Задача] сначала опиши фото, затем найди похожие\n[Сделай] find_images по тому, что видно; не ищи вслепую'
      : '[Задача] сказать, что видно на фото; неразборчивое не выдумывать';
  } else {
    card = '';
  }
  if (wantsTable && intent !== 'create' && intent !== 'code') {
    const tableLine = '[Сделай] сравнение markdown-таблицей | критерий | объекты |; не дублируй таблицу списком';
    card = card ? `${card}\n${tableLine}` : `[Задача] сравнить\n${tableLine}`;
  }
  if (nowLabel) card = card ? `${card}\n[Сейчас] ${nowLabel}` : `[Сейчас] ${nowLabel}`;
  return card;
}

// Общие правила качества ответа. Короткие и конкретные: 4B/9B лучше следуют
// пяти ясным правилам, чем длинной инструкции.
const ANSWER_RULES = [
  'Отвечай на языке последнего сообщения пользователя, если он не просит иначе.',
  'Сначала суть, затем детали. Без вступлений вроде «Отличный вопрос» и без пересказа вопроса.',
  'Длина по сложности: простое — пара предложений, сложное — по шагам или разделам, без воды. Списки и заголовки только там, где они помогают.',
  'Не знаешь или не уверен — скажи прямо; не выдумывай факты, цифры, цитаты и ссылки. Если пользователь ошибается — вежливо поправь, не поддакивай.',
  'Если вопрос двусмысленный, ответь на самое вероятное прочтение и коротко скажи, как его понял.',
].join(' ');

function intentInstructions({
  intent, provider, isCoder, preferFiles, evidencePresent, sandboxFiles,
}) {
  const filesNote = sandboxFiles.length
    ? `Песочница: ${sandboxFiles.slice(0, 24).join(', ')}${sandboxFiles.length > 24 ? '…' : ''}.`
    : '';
  if (intent === 'capability') {
    return 'Mentis 3, Nage 1.5 и Matle 2.5. Чат, вложения, PDF/PPTX/DOCX/XLSX, фото, аудио, поиск при ключе, Groq по желанию.';
  }
  if (intent === 'audio') {
    return 'Это распознанная аудиозапись. Если это речь — опирайся на текст. Если музыка без слов — так и скажи; не обещай внешний API.';
  }
  if (intent === 'file_qa' || intent === 'vision_files') {
    const ground = evidencePresent
      ? 'Фрагменты файлов уже подобраны в сообщении пользователя. Отвечай по ним. Не говори, что файла нет. search_file/read_file — только если фрагментов мало.'
      : 'Текст файлов в чат не вставлен. Сначала search_file по смыслу, затем read_file с offset/limit.';
    return `${ground} ${filesNote} Цифры и имена копируй буквально.`.trim();
  }
  if (intent === 'code' || intent === 'create' || isCoder) {
    const coder = isCoder
      ? 'Ты Matle 2.5. Не цитируй пользователя. Новый файл — write_file/copy_code_to_file. Правка существующего — replace_in_file с точным old_string из фрагмента, не переписывай весь файл. Затем проверка. JSON инструментов не печатай. В конце краткий итог и [имя](sandbox:путь).'
      : (intent === 'create' && provider === 'local'
        ? 'Документ — инструмент create_document (path, format, markdown в content). Не отказывайся и не проси копировать в Word. После вызова — одно короткое предложение.'
        : (provider === 'local'
          ? (filesNote ? filesNote : 'Новый код — write_file.')
          : 'Если нужен файл — блок ```язык:имя.ext.'));
    const matle = isCoder
      ? ' [ОБЯЗАТЕЛЬНЫЙ ФОРМАТ MATLE] Никаких fenced-блоков кода пользователю и никакого JSON вида {"name":"list_files"}.'
      : '';
    const empty = provider === 'local' && isCoder && !sandboxFiles.length
      ? ' Песочница пуста — новый файл через write_file.'
      : (filesNote ? ` ${filesNote}` : '');
    return `${coder}${matle}${empty}`;
  }
  if (intent === 'vision') {
    return 'Смотри приложенные фото. Говори то, что видно; неразборчивое не выдумывай.';
  }
  if (intent === 'search') {
    return 'Опирайся на найденные источники. Не выдумывай ссылки. Сначала факт, потом коротко откуда. Если изображения уже скачаны в этот ответ — не ищи их снова, галерея появится сама.';
  }
  if (intent === 'continue') {
    return 'Продолжи строго с места обрыва, без вступления.';
  }
  if (intent === 'explain') {
    return 'Объясняй от простого к сложному, с одним конкретным примером; термины раскрывай при первом упоминании.';
  }
  return '';
}

export function buildSystemPrompt(ctx = {}) {
  const {
    identityBlock = '',
    nowStr = '',
    intent = 'chat',
    searchAvailable = false,
    continueMsg = false,
    provider = 'local',
    isCoder = false,
    prefersTy = false,
    memoryBlock = '',
    effortNote = '',
    sandboxFiles = [],
    evidencePresent = false,
    reusableCodeBlocks = [],
    resolvedAnswers = [],
    chatSummary = '',
    droppedDigest = '',
    requestTopicId = 0,
    conciseCapability = false,
    preferFiles = false,
    allowQuestions = false,
  } = ctx;

  const parts = [];
  parts.push(identityBlock || 'Тебя зовут AmIgo. Ты чат-ассистент приложения AmIgo.');
  parts.push(`Говори о себе в мужском роде.${nowStr ? ` Сейчас: ${nowStr}.` : ''}`);
  parts.push('Не называй базовую модель. Последнее сообщение — задача. Результаты инструментов не выдумывай.');
  // Слой политики как у облачных API: обычный разговор — короткие правила
  // качества; файлы/код/опрос возможностей живут своими карточками, без смеси.
  const wantsRules = !isCoder && !continueMsg && ['chat', 'explain', 'search', 'vision'].includes(intent);
  parts.push(wantsRules ? ANSWER_RULES : 'Отвечай на языке пользователя; по умолчанию по-русски.');
  if (prefersTy) parts.push('Пользователь выбрал «ты» — только «ты».');

  parts.push(intentInstructions({
    intent, provider, isCoder, preferFiles, evidencePresent, sandboxFiles,
  }));

  if (continueMsg) {
    parts.push('Продолжение: новый поиск не делай.');
  } else if (!searchAvailable && intent === 'search') {
    parts.push('Нет поиска — свежие новости и котировки не подтверждай.');
  }

  if (!continueMsg && !isCoder && allowQuestions && ['chat', 'create'].includes(intent)) {
    parts.push('Уточнения — один блок ```question JSON {question, multiple, options}. Иначе сразу делай.');
  }

  if (memoryBlock) parts.push(memoryBlock.trim());
  if (effortNote) parts.push(effortNote);
  if (conciseCapability) {
    parts.push('О возможностях — только то, что умеет приложение.');
  }
  if (resolvedAnswers.length) {
    const known = resolvedAnswers.slice(-16).map((item) => `- ${item.question} — ${item.answer}`).join('\n');
    parts.push(`[УЖЕ ПОЛУЧЕННЫЕ ОТВЕТЫ ПОЛЬЗОВАТЕЛЯ]\n${known}\nЭти вопросы закрыты — не задавай их снова.`);
  }
  if (provider === 'local' && reusableCodeBlocks.length && (intent === 'code' || intent === 'create' || isCoder)) {
    parts.push(`[Доступные блоки кода для copy_code_to_file]\n${reusableCodeBlocks.map((block) => `${block.id}: ${block.label} (${block.language})`).join('\n')}`);
  }
  if (requestTopicId === 0 && chatSummary) {
    parts.push(`[Справочная сводка]\n${chatSummary}`);
  }
  if (droppedDigest) parts.push(droppedDigest);
  if (requestTopicId > 0) {
    parts.push('[КОНТЕКСТ ТЕМЫ] Тема сменилась. Прежнее игнорируй, если не упомянуто сейчас.');
  }

  return parts.filter(Boolean).join('\n');
}
