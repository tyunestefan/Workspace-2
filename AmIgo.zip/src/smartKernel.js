// Ядро вокруг модели: маршруты, факты, sampler.
// 4B/9B умнеют, когда задача собрана за них, а не свалена в промпт.

import { tokenize } from './retriever.js';

export function expandSearchQuery(text) {
  const source = String(text || '');
  const quoted = [...source.matchAll(/[«"']([^«"']{2,80})[»"']/g)].map((match) => match[1].trim());
  const files = [...source.matchAll(/\b[\w./-]+\.(?:pdf|docx?|pptx?|xlsx?|txt|md|csv|json|py|js|jsx|ts|tsx|html|css|rs|go|java)\b/gi)]
    .map((match) => match[0]);
  const numbers = source.match(/\d+(?:[.,]\d+)?%?|\d{1,2}[./]\d{1,2}[./]\d{2,4}/g) || [];
  const tokens = tokenize(source);
  const seen = new Set();
  const parts = [];
  for (const part of [...quoted, ...files, ...numbers, ...tokens]) {
    const key = String(part).toLocaleLowerCase('ru');
    if (!key || seen.has(key)) continue;
    seen.add(key);
    parts.push(part);
  }
  return parts.join(' ').slice(0, 400);
}

export function mentionedFilenames(text, files = []) {
  const lower = String(text || '').toLocaleLowerCase('ru');
  if (!lower.trim()) return [];
  return (files || []).filter((name) => {
    const base = String(name || '').split(/[\\/]/).pop();
    if (!base) return false;
    const needle = base.toLocaleLowerCase('ru');
    return lower.includes(needle) || lower.includes(needle.replace(/\.[^.]+$/, ''));
  });
}

export function extractDurableFacts(messages) {
  const facts = [];
  const seen = new Set();
  const add = (line) => {
    const key = line.toLocaleLowerCase('ru');
    if (seen.has(key)) return;
    seen.add(key);
    facts.push(line);
  };
  for (const message of messages || []) {
    if (message.role !== 'user') continue;
    const text = String(message.content || '');
    const name = text.match(/(?:меня зовут|моё имя|мое имя|зови меня)\s+([A-ZА-ЯЁ][\p{L}'-]+(?:\s+[A-ZА-ЯЁ][\p{L}'-]+)?)/iu);
    if (name) add(`Имя: ${name[1]}`);
    const work = text.match(/я работаю\s+(?:как\s+)?(?!на\s+[A-Za-z])([^.!?\n]{3,70})/i);
    if (work) add(`Работа: ${work[1].trim().replace(/[.,;]+$/, '')}`);
    const prefer = text.match(/я (?:предпочитаю|люблю)\s+([^.!?\n]{3,70})/i);
    if (prefer) add(`Предпочтение: ${prefer[1].trim().replace(/[.,;]+$/, '')}`);
    const live = text.match(/я живу\s+(?:в|на)\s+([^.!?\n]{2,40})/i);
    if (live) add(`Город: ${live[1].trim().replace(/[.,;]+$/, '')}`);
    const lang = text.match(/(?:говори|отвечай|пиши|давай)\s+(?:мне\s+)?(?:на\s+)?(?:языке\s+)?(русск\w*|английск\w*|english|russian|немецк\w*|французск\w*|испанск\w*|китайск\w*|польск\w*)/i);
    if (lang) add(`Язык: ${lang[1]}`);
    const stack = text.match(/(?:я (?:пишу|программирую|работаю)\s+на|наш стек[:\s]+|стек проекта[:\s]+)\s*([A-Za-z][A-Za-z0-9.+#]{1,24}(?:\s*(?:,|и|\/)\s*[A-Za-z][A-Za-z0-9.+#]{1,24}){0,4})/i);
    if (stack) add(`Стек: ${stack[1].trim().replace(/[.,;]+$/, '')}`);
    const project = text.match(/(?:проект(?:а|е)?|репозитори[йяе]|приложение)\s+(?:называется|под названием)?\s*[«"']?([A-Za-zА-ЯЁ][\w.-]{1,40})/i);
    if (project) add(`Проект: ${project[1]}`);
  }
  return facts.slice(0, 8);
}

export function looksLikeGroundingFailure(text) {
  const source = String(text || '');
  if (!source.trim()) return false;
  if (/(?:во фрагмент|согласно (?:файлу|документу)|в «[^»]+»|источник \d)/i.test(source)) return false;
  return /не (?:могу|удалось) (?:прочитат|открыт|получить доступ|увидеть)|нет доступа|файл(?:а|ов)? нет|не вижу (?:файл|документ|вложен)|не прикрепл|не получил(?:а|о)? (?:файл|документ)|у меня нет[\s\S]{0,40}файл/i.test(source);
}

export function samplerForIntent(intent, effort = {}) {
  const baseTemp = Number(effort.temperature) > 0 ? Number(effort.temperature) : 0.7;
  const maxTokens = Number(effort.max_tokens) > 0 ? Number(effort.max_tokens) : 8192;
  if (intent === 'file_qa') return { temperature: Math.min(baseTemp, 0.6), max_tokens: maxTokens };
  if (intent === 'capability') return { temperature: 0.5, max_tokens: 900 };
  if (intent === 'code' || intent === 'create') return { temperature: Math.min(baseTemp, 0.55), max_tokens: maxTokens };
  if (intent === 'search') return { temperature: Math.min(baseTemp, 0.55), max_tokens: maxTokens };
  if (intent === 'vision' || intent === 'vision_files') return { temperature: Math.min(baseTemp, 0.55), max_tokens: maxTokens };
  return { temperature: baseTemp, max_tokens: maxTokens };
}
