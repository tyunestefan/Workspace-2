// Восстановление таблиц из того, что 4B/9B реально пишут: markdown с «|»,
// TSV и «столбиком» (заголовок, потом значения группами). Без UI.

export function hasPipeTable(text) {
  const lines = String(text || '').split(/\n/);
  return lines.some((line) => {
    const t = line.trim();
    return t.includes('|') && t.split('|').filter((cell) => cell.trim()).length >= 2;
  });
}

export function looksLikeDocumentNarration(text) {
  const source = String(text || '');
  return /успешно создан|уже создал|уже сделал|файл сохран[её]н|write_file|песочниц|не могу создать|именованн(?:ый|ого) блок/i.test(source)
    && !hasPipeTable(source);
}

export function tableToMarkdown(rows) {
  const list = (rows || []).map((row) => (Array.isArray(row) ? row : [String(row || '')]));
  if (!list.length) return '';
  const width = Math.max(1, ...list.map((row) => row.length));
  const padded = list.map((row) => {
    const next = row.map((cell) => String(cell || '').replace(/\s+/g, ' ').trim());
    while (next.length < width) next.push('');
    return next;
  });
  const line = (row) => `| ${row.map((cell) => cell.replace(/\|/g, '\\|')).join(' | ')} |`;
  const sep = `| ${padded[0].map(() => '---').join(' | ')} |`;
  return [line(padded[0]), sep, ...padded.slice(1).map(line)].join('\n');
}

export function reshapeSequentialLines(items) {
  const list = (items || []).map((item) => String(item || '').trim()).filter(Boolean);
  if (list.length < 6) return null;
  let best = null;
  for (let width = 3; width <= 8; width += 1) {
    if (list.length % width !== 0) continue;
    const rows = [];
    for (let index = 0; index < list.length; index += width) {
      rows.push(list.slice(index, index + width));
    }
    if (rows.length < 2) continue;
    const firstCol = rows.map((row) => row[0]);
    const dataLabels = firstCol.slice(1);
    const goodLabels = dataLabels.filter((cell) => /^[\p{L}][\p{L}\s-]{1,40}$/u.test(cell) && !/\d/.test(cell)).length;
    if (dataLabels.length && goodLabels < Math.max(1, dataLabels.length - 1)) continue;
    let score = rows.length * 10 + goodLabels;
    if (/параметр|показател|характеристик/i.test(rows[0][0])) score += 50;
    if (!best || score > best.score) best = { rows, score };
  }
  return best?.rows || null;
}

export function tablesFromLooseText(src) {
  const lines = String(src || '').replace(/\r\n/g, '\n').split('\n').map((line) => line.trim());
  let start = lines.findIndex((line) => /таблиц|параметр/i.test(line));
  if (start < 0) start = 0;
  if (lines[start] && /таблиц/i.test(lines[start]) && !/параметр/i.test(lines[start])) start += 1;
  const body = [];
  for (let index = start; index < lines.length; index += 1) {
    const line = lines[index];
    if (!line) continue;
    if (/^#{1,3}\s/.test(line)) break;
    if (line.length > 140) continue;
    body.push(line);
  }
  return reshapeSequentialLines(body);
}

// Для ответа в чате: столбик «Параметр / A / B / …» превращаем в markdown-таблицу,
// вступление и выводы оставляем. Документы идут через normalizeDocumentSource.
export function injectRecoveredTable(src) {
  const original = String(src || '').trim();
  if (!original || hasPipeTable(original)) return original;
  const recovered = tablesFromLooseText(original);
  if (!recovered) return original;
  const markdown = tableToMarkdown(recovered);
  const used = new Set(recovered.flat().map((cell) => cell.toLocaleLowerCase('ru')));
  const leftover = original.split('\n').filter((line) => {
    const t = line.trim();
    if (!t) return true;
    if (used.has(t.toLocaleLowerCase('ru'))) return false;
    if (/^(?:#{1,6}\s+)?(?:сравнен|таблиц|основные аналоги)/i.test(t) && t.length <= 80) return false;
    return true;
  }).join('\n').replace(/\n{3,}/g, '\n\n').trim();
  return [leftover, markdown].filter(Boolean).join('\n\n');
}

export function normalizeDocumentSource(src) {
  const original = String(src || '').trim();
  if (!original) return '';
  if (looksLikeDocumentNarration(original)) return '';
  if (hasPipeTable(original)) return original;
  const recovered = tablesFromLooseText(original);
  if (!recovered) return original;
  const used = new Set(recovered.flat().map((cell) => cell.toLocaleLowerCase('ru')));
  const title = original.split('\n')
    .map((line) => line.trim())
    .filter((line) => line && line.length <= 80 && !used.has(line.toLocaleLowerCase('ru')))
    .filter((line) => !/таблиц|параметр|введение|основные аналоги/i.test(line))
    .slice(0, 2);
  const heading = title.map((line) => (line.startsWith('#') ? line : `# ${line}`)).join('\n');
  const markdown = tableToMarkdown(recovered);
  return [heading, markdown].filter(Boolean).join('\n\n');
}
