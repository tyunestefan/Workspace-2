import assert from 'node:assert/strict';
import {
  buildSystemPrompt,
  buildTaskCard,
  classifyTurn,
  collectAttachmentDocuments,
  compactDroppedMessages,
  shouldGatherEvidence,
  wantsComparisonTable,
} from '../src/orchestrator.js';

assert.equal(classifyTurn({ text: 'Привет' }).intent, 'chat');
assert.equal(classifyTurn({ text: 'Расскажи, что умеешь' }).intent, 'capability');
assert.equal(classifyTurn({
  text: 'А что еще',
  previousUser: 'Расскажи, что умеешь',
}).intent, 'capability');
assert.equal(classifyTurn({
  text: 'Напиши мне текст этой песни',
  attachments: [{ kind: 'audio', name: 'a.mp3' }],
}).intent, 'audio');
assert.equal(classifyTurn({
  text: 'Что в этом файле?',
  attachments: [{ kind: 'text', name: 'a.pdf', text: 'hello' }],
}).intent, 'file_qa');
assert.equal(classifyTurn({
  text: 'Напиши змейку на python',
}).intent, 'code');
assert.equal(classifyTurn({
  text: 'Хорошо а оформи жто в pdf',
  sandboxFiles: ['notes.md'],
}).intent, 'create');
assert.equal(classifyTurn({
  text: 'а ты можешь сделать документ с таблицей сравнения МС 21-310 и его аналогов?',
}).intent, 'create');
assert.equal(classifyTurn({
  text: 'оформи это в pdf',
  attachments: [{ kind: 'text', name: 'a.pdf', text: 'hello' }],
}).intent, 'create');
assert.equal(classifyTurn({
  text: 'Или просто тестовый документ с текстом «Привет, это PDF»? — да',
}).intent, 'create');
assert.equal(classifyTurn({
  text: 'Что на фото?',
  attachments: [{ kind: 'image', name: 'a.png' }],
}).intent, 'vision');
assert.equal(classifyTurn({
  text: 'посмотри на картинку и найди похожие',
  attachments: [{ kind: 'image', name: 'plane.png' }],
}).searchAfterVision, true);
assert.match(buildTaskCard({ intent: 'vision', searchAfterVision: true }), /find_images/);
assert.equal(classifyTurn({
  text: 'найди курс евро',
  searchAvailable: true,
}).intent, 'search');
assert.equal(classifyTurn({
  text: 'Покажи картину Мона Лиза',
  searchAvailable: true,
}).intent, 'search');

assert.equal(shouldGatherEvidence({
  intent: 'chat',
  attachments: [{ kind: 'text', name: 'a.txt' }],
  sandboxFiles: [],
}), true);
assert.equal(shouldGatherEvidence({
  intent: 'chat',
  attachments: [],
  sandboxFiles: ['note.txt'],
}), false);
assert.equal(shouldGatherEvidence({
  intent: 'file_qa',
  attachments: [],
  sandboxFiles: ['note.txt'],
}), true);
assert.equal(shouldGatherEvidence({
  intent: 'file_qa',
  continueMsg: true,
  attachments: [{ kind: 'text' }],
  sandboxFiles: ['note.txt'],
}), false);

const docs = collectAttachmentDocuments([
  { attachments: [{ kind: 'text', name: 'a.txt', text: 'AAA' }, { kind: 'image', name: 'p.png' }] },
  { attachments: [{ kind: 'text', sandboxPath: 'a.txt', text: 'dup' }] },
]);
assert.equal(docs.length, 1);
assert.equal(docs[0].name, 'a.txt');

const digest = compactDroppedMessages([
  { role: 'user', content: 'Старый вопрос про погоду в Липецке подробно' },
  { role: 'assistant', content: 'Ответ про погоду был длинный и больше не нужен для новой темы' },
]);
assert.match(digest, /Сжатая ранняя история/);
assert.match(digest, /Пользователь/);

const system = buildSystemPrompt({
  identityBlock: 'Тебя зовут Nage 1.5.',
  nowStr: 'четверг',
  intent: 'file_qa',
  provider: 'local',
  evidencePresent: true,
  sandboxFiles: ['report.pdf'],
  preferFiles: true,
});
assert.match(system, /Nage 1\.5/);
assert.match(system, /Фрагменты файлов уже подобраны/);
assert.match(system, /report\.pdf/);
assert.doesNotMatch(system, /АВТОМАТИЧЕСКИ вставляет галерею/);
assert.doesNotMatch(system, /web_search/);
assert.doesNotMatch(system, /```question/);

const chatSystem = buildSystemPrompt({
  identityBlock: 'Тебя зовут Nage 1.5.',
  intent: 'chat',
  provider: 'local',
  sandboxFiles: [],
});
const capSystem = buildSystemPrompt({
  identityBlock: 'Тебя зовут Nage 1.5. Ты AmIgo — ассистент приложения AmIgo на Mac.',
  intent: 'capability',
  provider: 'local',
});
assert.match(capSystem, /Mentis 3/);
assert.match(capSystem, /AmIgo/);
assert.doesNotMatch(chatSystem, /Finder|macos|не управляешь компьютером/i);
assert.doesNotMatch(capSystem, /самореклам/);

assert.match(chatSystem, /задач/);
assert.doesNotMatch(chatSystem, /write_file/);
assert.doesNotMatch(chatSystem, /предполож/);
assert.doesNotMatch(chatSystem, /для обычного разговора не вызывай/);
assert.doesNotMatch(chatSystem, /web_search/);
assert.doesNotMatch(chatSystem, /Поиск выключен/);
assert.doesNotMatch(chatSystem, /question/);

assert.equal(classifyTurn({ text: 'Объясни теорию относительности' }).intent, 'explain');
assert.equal(classifyTurn({ text: 'Привет' }).intent, 'chat');
assert.equal(classifyTurn({
  text: 'Привет',
  sandboxFiles: ['test_document.pdf'],
}).intent, 'chat');


const fileCard = buildTaskCard({ intent: 'file_qa', evidencePresent: true });
assert.match(fileCard, /\[Задача\]/);
assert.match(fileCard, /фрагментам ниже/);
assert.equal(buildTaskCard({ intent: 'chat', isCoder: true }), '');
assert.match(buildTaskCard({ intent: 'create' }), /create_document/);
assert.doesNotMatch(buildTaskCard({ intent: 'explain' }), /Коротко|Кратко|Подробно|предполож/);
assert.match(buildTaskCard({ intent: 'explain', nowLabel: '21:40' }), /\[Сейчас\] 21:40/);
assert.match(buildTaskCard({ intent: 'search' }), /источник/);
assert.match(buildTaskCard({ intent: 'chat', nowLabel: '21:40' }), /\[Сейчас\] 21:40/);
assert.doesNotMatch(buildTaskCard({ intent: 'chat' }), /\[Сейчас\]/);
assert.equal(wantsComparisonTable('сравни MC-21-310 и 737 MAX'), true);
assert.equal(wantsComparisonTable('в чём разница между pdf и docx'), true);
assert.equal(wantsComparisonTable('сравнительно недавно'), false);
assert.equal(wantsComparisonTable('Привет'), false);
assert.match(buildTaskCard({ intent: 'chat', wantsTable: true }), /markdown-таблиц/);
assert.doesNotMatch(buildTaskCard({ intent: 'chat' }), /markdown-таблиц/);
assert.match(buildTaskCard({ intent: 'vision', wantsTable: true }), /markdown-таблиц/);
assert.doesNotMatch(
  buildSystemPrompt({ identityBlock: 'Тебя зовут Nage 1.5.', intent: 'chat', allowQuestions: false }),
  /question/,
);

// Общие правила ответа: есть в обычном чате, нет в кодовом агенте и коротких режимах.
assert.match(chatSystem, /Сначала суть/);
assert.match(chatSystem, /не выдумывай факты/);
assert.doesNotMatch(buildSystemPrompt({ intent: 'chat', isCoder: true }), /Сначала суть/);
assert.doesNotMatch(buildSystemPrompt({ intent: 'capability' }), /Сначала суть/);
assert.doesNotMatch(buildSystemPrompt({ intent: 'create' }), /Сначала суть/);
assert.match(buildSystemPrompt({ intent: 'create', provider: 'local' }), /create_document/);
assert.doesNotMatch(buildSystemPrompt({ intent: 'file_qa' }), /Сначала суть/);
assert.doesNotMatch(buildSystemPrompt({ intent: 'chat', continueMsg: true }), /Сначала суть/);
assert.match(buildSystemPrompt({ intent: 'explain' }), /от простого к сложному/);

console.log('Orchestrator tests passed.');
