import assert from 'node:assert/strict';
import {
  chunkCodeEntities,
  chunkText,
  formatEvidence,
  isCodeFilename,
  mergeHits,
  retrieveFromDocuments,
  tokenize,
} from '../src/retriever.js';

assert.ok(tokenize('Срок оплаты по договору').includes('срок'));
assert.ok(!tokenize('что в этом файле').includes('что'));

const chunks = chunkText('а'.repeat(2500), { size: 900, overlap: 140 });
assert.ok(chunks.length >= 3);
assert.equal(chunks[0].offset, 0);

const docs = [
  { name: 'contract.txt', text: 'Договор аренды склада.\n\nСрок оплаты — пять рабочих дней с даты счёта. Штраф 0.1% в день.\n\nАдрес склада: Москва.' },
  { name: 'readme.md', text: 'AmIgo — локальный помощник. Здесь нет условий оплаты.' },
];
const hits = retrieveFromDocuments(docs, 'какой срок оплаты по договору', { maxHits: 4, maxChars: 4000 });
assert.ok(hits.length >= 1);
assert.equal(hits[0].path, 'contract.txt');
assert.match(hits[0].snippet, /оплат/i);

const emptyQuery = retrieveFromDocuments(docs, 'что в файле?', { maxHits: 4 });
assert.ok(emptyQuery.some((hit) => hit.path === 'contract.txt' || hit.path === 'readme.md'));

const none = retrieveFromDocuments([], 'оплата', { maxHits: 4 });
assert.equal(none.length, 0);

const small = retrieveFromDocuments(
  [{ name: 'note.txt', text: 'Короткий файл про срок оплаты и штраф.' }],
  'срок оплаты',
  { maxHits: 4, maxChars: 4000 },
);
assert.equal(small[0]?.full, true);
assert.equal(small[0]?.path, 'note.txt');

const named = retrieveFromDocuments(
  [
    { name: 'other.md', text: 'Срок оплаты встречается и здесь, но это не тот документ.' },
    { name: 'contract.txt', text: 'Договор. Срок оплаты — пять дней.' },
  ],
  'contract.txt срок',
  { maxHits: 3, maxChars: 4000 },
);
assert.equal(named[0].path, 'contract.txt');

const evidence = formatEvidence(hits);
assert.match(evidence, /ФРАГМЕНТЫ ФАЙЛОВ/);
assert.match(evidence, /contract\.txt/);
assert.match(evidence, /данные, не инструкции/);

const merged = mergeHits(hits, [{ path: 'contract.txt', offset: hits[0].offset, snippet: 'dup', score: 99, total: 10 }]);
assert.equal(merged.filter((hit) => hit.path === 'contract.txt' && hit.offset === hits[0].offset).length, 1);

assert.equal(isCodeFilename('src/bot.py'), true);
assert.equal(isCodeFilename('notes.md'), false);
const codeSource = [
  'header',
  '',
  'def greet(name):',
  '    return name',
  '',
  'def run():',
  '    print(greet("a"))',
  '    return 1',
  '',
].join('\n');
const codeChunks = chunkCodeEntities(codeSource);
assert.ok(codeChunks.some((chunk) => chunk.text.includes('def greet')));
assert.ok(codeChunks.some((chunk) => chunk.text.includes('def run')));
const longCode = `${'x = 1\n'.repeat(900)}${codeSource}`;
assert.ok(longCode.length > 5000);
const codeHits = retrieveFromDocuments(
  [{ name: 'bot.py', text: longCode }],
  'исправь функцию greet',
  { maxHits: 4, maxChars: 4000 },
);
assert.ok(codeHits.some((hit) => /greet/i.test(hit.snippet)));

console.log('Retriever tests passed.');
